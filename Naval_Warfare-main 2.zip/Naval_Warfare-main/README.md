# EECS 581 Battleship Game
EECS 581 Team 5 Project Update
By: Jawad Ahsan, Dev Patel, Sanketh Reddy, Yadhunath Tharakeswaran, Kemar Wilson

We have added the code for Sprint 1 in the main.py file. 

